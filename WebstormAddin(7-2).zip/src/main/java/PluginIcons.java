import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

public interface PluginIcons {
   public Icon TOOL_WINDOW = IconLoader.getIcon("/icons/vaultIcon.png");
}
